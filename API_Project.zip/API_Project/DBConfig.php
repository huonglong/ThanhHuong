<?php

//Define your host here.
$HostName = "localhost";

//Define your database name here.
$DatabaseName = "QuanLyXeChoThue";

//Define your database username here.
$HostUser = "root";

//Define your database password here.
$HostPass = "mysql";

mysql_query('SET NAMES utf8');

?>